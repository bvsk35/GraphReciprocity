library(Matrix)
# Generate PA data
set.seed(1234)
edgelist = simPA(0.2, 0.7, 1, 1, 0.2, 100000, matrix(c(1, 1), nrow = 1), TRUE, 1, c(1, 1))
A = sparseMatrix(edgelist[, 1], edgelist[, 2], x = rep(1, nrow(edgelist)), dims = c(max(edgelist), max(edgelist)))
writeMM(A, file = "PAdata.mtx")